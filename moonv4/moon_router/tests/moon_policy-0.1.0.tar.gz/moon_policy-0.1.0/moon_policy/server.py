# Copyright 2015 Open Platform for NFV Project, Inc. and its contributors
# This software is distributed under the terms and conditions of the 'Apache-2.0'
# license which can be found in the file 'LICENSE' in this package distribution
# or at 'http://www.apache.org/licenses/LICENSE-2.0'.

import json
import importlib
from moon_policy import __version__
from moon_policy.config import get_config
import logging
import logging.config
import subprocess
import re
from io import BytesIO
from docker import Client

global_config = get_config(confdir="policy")
logger = logging.getLogger("moon_policy")
# print(global_config['logging'])
# logging.config.dictConfig(global_config['logging'])


def get_ip():
    p = subprocess.Popen(["ip", "address"], stdout=subprocess.PIPE)
    out, err = p.communicate()
    result = {}
    tag = ""
    for line in str(out.decode("utf-8")).splitlines():
        if re.match("^\s", line):
            if re.match("\s+inet\s", line):
                result[tag] = line.split()[1]
        else:
            tag = line.split(":")[1]
    return result


class Authz:

    def compute(self, tenant_id, subject_id, object_id, action_id):
        """Ask an extension if this action is authorized

        :param tenant_id: the ID of the tenant
        :param subject_id: the ID of the subject
        :param object_id: the ID of the object
        :param action_id: the ID of the action
        :return: a dictionary containing:
         {
            "authz": True_or_False,
            "message": "a description if the authorisation is False"
         }
        """
        raise NotImplementedError()

    def create(self, data, **kwargs):
        """Create a new set of extensions

        :param data: data used to create the new set of extensions
            Example of data:
                {
                    "tenant_id": "123456789",
                    "intraextension_id": "987654321"
                }
        :param kwargs: some arguments needed to create this set
        :return: a dictionary containing:
         {
            "result": True_or_False,
            "message": "a description if the set of extension was not created."
         }
        """
        logger.info("CREATE")
        dockerfile = '''
# Shared Volume
FROM busybox:buildroot-2014.02
MAINTAINER Thomas Duval, thomas.duval@orange.com
CMD ["/bin/echo", "alive"]
        '''
        f = BytesIO(dockerfile.encode('utf-8'))
        cli = Client(base_url='tcp://127.0.0.1:2375')
        response = [line for line in cli.build(fileobj=f, rm=True, tag='busybox/latest')]
        return {
            "result": str(response),
            "message": ""
        }

    def modify(self, tenant_id, data, **kwargs):
        """Modify a set of extensions

        :param tenant_id: the ID of the tenant
        :param data: data used to update the new set of extensions
        :param kwargs: some arguments needed to create this set
        :return: a dictionary containing:
         {
            "result": True_or_False,
            "message": "a description if the set of extension was not created."
         }
        """
        raise NotImplementedError()


class Root:

    def get(self):
        class_objects = (Root, )
        methods = ("get", "post", "put", "head", "delete", "options")
        tree = {}
        for co in class_objects:
            url = "/" + co.__name__.lower()
            if co.__name__.lower() == "root":  # nosec (not a hardcoded password)
                url = "/"
            tree[url] = {}
            tree[url]["methods"] = list(filter(lambda x: x in dir(co), methods))
            description = co.__doc__ or ""
            tree[url]["description"] = description.strip()
        return {"version": __version__, "tree": tree}


def main():
    authz = Authz()
    print("Starting server with IP {}".format(get_ip()))
    driver = importlib.import_module(global_config["main"]["api_driver"])
    driver.HTTPServer(
        host=global_config["main"]["host"],
        port=global_config["main"]["port"],
        api=authz
    )


if __name__ == '__main__':
    main()
