# Copyright 2015 Open Platform for NFV Project, Inc. and its contributors
# This software is distributed under the terms and conditions of the 'Apache-2.0'
# license which can be found in the file 'LICENSE' in this package distribution
# or at 'http://www.apache.org/licenses/LICENSE-2.0'.

import os
import yaml
import logging

logger = logging.getLogger("moon.config")


def get_config(confname="main.yaml", confdir=""):
    """Try to retrieve the best configuration file

    :param confname: name of the configuration file
    :param confdir: name of the configuration directory
    :return: a dictionary containing the configuration
    """
    _global_config = {}
    for filename in (
        confname,
        os.path.join(os.getcwd(), ".{}".format(confname)),
        os.path.join(os.getenv("HOME", "/tmp"), ".{}".format(confname)),  # nosec
        "/etc/moon/{0}/{1}".format(confdir, confname),
        os.path.join(confdir, confname),
    ):
        try:
            _global_config = yaml.safe_load(open(filename))
        except FileNotFoundError:
            continue
    if not _global_config:
        raise BaseException("Could not find a usable configuration file {}/{}".format(confdir, confname))
    return _global_config
