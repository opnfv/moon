# Copyright 2015 Open Platform for NFV Project, Inc. and its contributors
# This software is distributed under the terms and conditions of the 'Apache-2.0'
# license which can be found in the file 'LICENSE' in this package distribution
# or at 'http://www.apache.org/licenses/LICENSE-2.0'.


class Server:

    def __init__(self, host="localhost", port=80, api=None, **kwargs):
        """Run a server

        :param host: hostname of the server
        :param port: port for the running server
        :param kwargs: optional parameters
        :return: a running server
        """
        self._host = host
        self._port = port
        self._api = api
        self._extra = kwargs

    @property
    def host(self):
        return self._host

    @host.setter
    def host(self, name):
        self._host = name

    @host.deleter
    def host(self):
        self._host = ""

    @property
    def port(self):
        return self._port

    @port.setter
    def port(self, number):
        self._port = number

    @port.deleter
    def port(self):
        self._port = 80

    def run(self):
        raise NotImplementedError()


class Messenger:

    def __init__(self, host="localhost", port=80):
        self.__host = host
        self.__port = port

    @property
    def host(self):
        return self.__host

    @host.setter
    def host(self, name):
        self.__host = name

    @host.deleter
    def host(self):
        self.__host = ""

    @property
    def port(self):
        return self.__port

    @port.setter
    def port(self, number):
        self.__port = number

    @port.deleter
    def port(self):
        self.__port = 80

    def send(self, action, data, **kwargs):
        """Send a message

        :param action: the name of the action to be fired
        :param data: the data payload for that action
        :param kwargs: optional parameters
        :return: the returned code for that message
        """
        raise NotImplementedError()
