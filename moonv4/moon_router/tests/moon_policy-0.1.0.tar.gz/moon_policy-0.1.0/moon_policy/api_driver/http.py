# Copyright 2015 Open Platform for NFV Project, Inc. and its contributors
# This software is distributed under the terms and conditions of the 'Apache-2.0'
# license which can be found in the file 'LICENSE' in this package distribution
# or at 'http://www.apache.org/licenses/LICENSE-2.0'.

from flask import Flask, request
from flask_restful import Resource, Api, reqparse
import requests
import logging
import json
from moon_policy import __version__

from moon_policy.api_driver import driver

logger = logging.getLogger("moon_policy.http")


class HTTPServer(driver.Server):

    def __init__(self, host="localhost", port=80, **kwargs):
        super(HTTPServer, self).__init__(host=host, port=port, **kwargs)
        self.app = Flask(__name__)
        self.api = Api(self.app)
        self.api.add_resource(self.Root, '/')
        self.api.add_resource(self.Authz,
                              '/authz', '/authz/',
                              '/authz/<string:uuid>/<string:subject_id>/<string:object_id>/<string:action_id>')
        self.Authz._api = self._api
        self.Authz.logger = self.app.logger
        self.run()

    class Root(Resource):
        """
        The root of the web service
        """

        @staticmethod
        def get():
            return {
                "version": __version__,
                "tree": {
                    "/": {"methods": ("get",), "description": "List all methods for that service."},
                    "/authz": {"methods": ("get", "post", "put"), "description": "compute authz requests"},
                }
            }

    class Authz(Resource):
        """
        Endpoint for authorisation requests
        """

        def get(self, uuid=None, subject_id=None, object_id=None, action_id=None):
            return json.dumps(self._api.compute(uuid, subject_id, object_id, action_id))

        def post(self):
            return json.dumps(self._api.create(data=request.get_json()))

        def put(self, uuid=None):
            return json.dumps(self._api.modify(uuid, data=request))

    def run(self):
        self.app.run(debug=True, host=self._host, port=self._port)  # nosec


class HTTPMessenger(driver.Messenger):

    def __init__(self, host="localhost", port=80, **kwargs):
        super(HTTPMessenger, self).__init__(host=host, port=port)

    def send(self, action, data, **kwargs):
        if action.lower() == "compute":
            req = requests.get("http://{host}:{port}/authz/{tenant_id}/{subject_id}/{object_id}/{action_id}")
            if req.status_code == 200:
                return req.json()
            return {
                "result": False,
                "message": {
                    "code": req.status_code,
                    "description": req.reason
                }
            }

server = HTTPServer
messenger = HTTPMessenger