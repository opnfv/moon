# Copyright 2015 Open Platform for NFV Project, Inc. and its contributors
# This software is distributed under the terms and conditions of the 'Apache-2.0'
# license which can be found in the file 'LICENSE' in this package distribution
# or at 'http://www.apache.org/licenses/LICENSE-2.0'.

from moon_db.exception import *
from stevedore.driver import DriverManager


class Driver(DriverManager):

    def __init__(self, driver_name, engine_name):
        super(Driver, self).__init__(
            namespace='moon_db.driver',
            name=driver_name,
            invoke_on_load=True,
            invoke_args=(engine_name, ),
        )


class ConfigurationDriver(object):

    def get_policy_templates_dict(self):
        raise NotImplementedError()  # pragma: no cover

    def get_aggregation_algorithm_id(self):
        raise NotImplementedError()  # pragma: no cover

    def get_sub_meta_rule_algorithms_dict(self):
        raise NotImplementedError()  # pragma: no cover


class TenantDriver(object):

    def get_tenants_dict(self):
        raise NotImplementedError()  # pragma: no cover

    def add_tenant_dict(self, tenant_id, tenant_dict):
        raise NotImplementedError()  # pragma: no cover

    def del_tenant_dict(self, tenant_id):
        raise NotImplementedError()  # pragma: no cover

    def set_tenant_dict(self, tenant_id, tenant_dict):
        raise NotImplementedError()  # pragma: no cover


class IntraExtensionDriver(object):

    SUBJECT = 'subject'
    OBJECT = 'object'
    ACTION = 'action'
    SUBJECT_CATEGORY = 'subject_category'
    OBJECT_CATEGORY = 'object_category'
    ACTION_CATEGORY = 'action_category'
    SUBJECT_SCOPE = 'subject_scope'
    OBJECT_SCOPE = 'object_scope'
    ACTION_SCOPE = 'action_scope'
    SUB_META_RULE = 'sub_meta_rule'

    def __get_data_from_type(self,
                             intra_extension_uuid,
                             name=None,
                             uuid=None,
                             data_name=None,
                             category_name=None,
                             category_uuid=None):

        def extract_name(data_dict):
            for key in data_dict:
                try:
                    yield data_dict[key]["name"]
                except KeyError:
                    for key2 in data_dict[key]:
                        yield data_dict[key][key2]["name"]

        data_values = list()

        if data_name == self.SUBJECT:
            data_values = self.get_subjects_dict(intra_extension_uuid)
            if (name and name not in extract_name(data_values)) or \
                    (uuid and uuid not in data_values.keys()):
                raise SubjectUnknown("{} / {}".format(name, data_values))
        elif data_name == self.OBJECT:
            data_values = self.get_objects_dict(intra_extension_uuid)
            if (name and name not in extract_name(data_values)) or \
                    (uuid and uuid not in data_values.keys()):
                raise ObjectUnknown("{} / {}".format(name, data_values))
        elif data_name == self.ACTION:
            data_values = self.get_actions_dict(intra_extension_uuid)
            if (name and name not in extract_name(data_values)) or \
                    (uuid and uuid not in data_values.keys()):
                raise ActionUnknown("{} / {}".format(name, data_values))
        elif data_name == self.SUBJECT_CATEGORY:
            data_values = self.get_subject_categories_dict(intra_extension_uuid)
            if (name and name not in extract_name(data_values)) or \
                    (uuid and uuid not in data_values.keys()):
                raise SubjectCategoryUnknown("{} / {}".format(name, data_values))
        elif data_name == self.OBJECT_CATEGORY:
            data_values = self.get_object_categories_dict(intra_extension_uuid)
            if (name and name not in extract_name(data_values)) or \
                    (uuid and uuid not in data_values.keys()):
                raise ObjectCategoryUnknown("{} / {}".format(name, data_values))
        elif data_name == self.ACTION_CATEGORY:
            data_values = self.get_action_categories_dict(intra_extension_uuid)
            if (name and name not in extract_name(data_values)) or \
                    (uuid and uuid not in data_values.keys()):
                raise ActionCategoryUnknown("{} / {}".format(name, data_values))
        elif data_name == self.SUBJECT_SCOPE:
            if not category_uuid:
                category_uuid = self.get_uuid_from_name(intra_extension_uuid, category_name, self.SUBJECT_CATEGORY)
            data_values = self.get_subject_scopes_dict(intra_extension_uuid,
                                                       category_uuid)
            if (name and name not in extract_name(data_values)) or \
                    (uuid and uuid not in data_values.keys()):
                raise SubjectScopeUnknown("{} / {}".format(name, data_values))
        elif data_name == self.OBJECT_SCOPE:
            if not category_uuid:
                category_uuid = self.get_uuid_from_name(intra_extension_uuid, category_name, self.OBJECT_CATEGORY)
            data_values = self.get_object_scopes_dict(intra_extension_uuid,
                                                      category_uuid)
            if (name and name not in extract_name(data_values)) or \
                    (uuid and uuid not in data_values.keys()):
                raise ObjectScopeUnknown("{} / {}".format(name, data_values))
        elif data_name == self.ACTION_SCOPE:
            if not category_uuid:
                category_uuid = self.get_uuid_from_name(intra_extension_uuid, category_name, self.ACTION_CATEGORY)
            data_values = self.get_action_scopes_dict(intra_extension_uuid,
                                                      category_uuid)
            if (name and name not in extract_name(data_values)) or \
                    (uuid and uuid not in data_values.keys()):
                raise ActionScopeUnknown("{} / {}".format(name, data_values))
        elif data_name == self.SUB_META_RULE:
            data_values = self.get_sub_meta_rules_dict(intra_extension_uuid)
            if (name and name not in extract_name(data_values)) or \
                    (uuid and uuid not in data_values.keys()):
                raise SubMetaRuleUnknown("{} / {}".format(name, data_values))
        # if data_name in (
        #     self.SUBJECT_SCOPE,
        #     self.OBJECT_SCOPE,
        #     self.ACTION_SCOPE
        # ):
        #     return data_values[category_uuid]
        return data_values

    def get_uuid_from_name(self, intra_extension_uuid, name, data_name, category_name=None, category_uuid=None):
        data_values = self.__get_data_from_type(
            intra_extension_uuid=intra_extension_uuid,
            name=name,
            data_name=data_name,
            category_name=category_name,
            category_uuid=category_uuid,
        )
        return filter(lambda v: v[1]["name"] == name, data_values.iteritems())[0][0]

    def get_name_from_uuid(self, intra_extension_uuid, uuid, data_name, category_name=None, category_uuid=None):
        data_values = self.__get_data_from_type(
            intra_extension_uuid=intra_extension_uuid,
            uuid=uuid,
            data_name=data_name,
            category_name=category_name,
            category_uuid=category_uuid,
        )
        return data_values[uuid]

    # Getter and Setter for intra_extension

    def get_intra_extensions_dict(self):
        raise NotImplementedError()  # pragma: no cover

    def del_intra_extension(self, intra_extension_id):
        raise NotImplementedError()  # pragma: no cover

    def set_intra_extension_dict(self, intra_extension_id, intra_extension_dict):
        raise NotImplementedError()  # pragma: no cover

    # Metadata functions

    def get_subject_categories_dict(self, intra_extension_id):
        raise NotImplementedError()  # pragma: no cover

    def set_subject_category_dict(self, intra_extension_id, subject_category_id, subject_category_dict):
        raise NotImplementedError()  # pragma: no cover

    def del_subject_category(self, intra_extension_id, subject_category_id):
        raise NotImplementedError()  # pragma: no cover

    def get_object_categories_dict(self, intra_extension_id):
        """Get a list of all object categories

        :param intra_extension_id: IntraExtension UUID
        :type intra_extension_id: string
        :return: a dictionary containing all object categories {"uuid1": "name1", "uuid2": "name2"}
        """
        raise NotImplementedError()  # pragma: no cover

    def set_object_category_dict(self, intra_extension_id, object_category_id, object_category_dict):
        raise NotImplementedError()  # pragma: no cover

    def del_object_category(self, intra_extension_id, object_category_id):
        raise NotImplementedError()  # pragma: no cover

    def get_action_categories_dict(self, intra_extension_id):
        raise NotImplementedError()  # pragma: no cover

    def set_action_category_dict(self, intra_extension_id, action_category_id, action_category_dict):
        raise NotImplementedError()  # pragma: no cover

    def del_action_category(self, intra_extension_id, action_category_id):
        raise NotImplementedError()  # pragma: no cover

    #  Perimeter functions

    def get_subjects_dict(self, intra_extension_id):
        raise NotImplementedError()  # pragma: no cover

    def set_subject_dict(self, intra_extension_id, subject_id, subject_dict):
        raise NotImplementedError()  # pragma: no cover

    def del_subject(self, intra_extension_id, subject_id):
        raise NotImplementedError()  # pragma: no cover

    def get_objects_dict(self, intra_extension_id):
        raise NotImplementedError()  # pragma: no cover

    def set_object_dict(self, intra_extension_id, object_id, object_dict):
        raise NotImplementedError()  # pragma: no cover

    def del_object(self, intra_extension_id, object_id):
        raise NotImplementedError()  # pragma: no cover

    def get_actions_dict(self, intra_extension_id):
        raise NotImplementedError()  # pragma: no cover

    def set_action_dict(self, intra_extension_id, action_id, action_dict):
        raise NotImplementedError()  # pragma: no cover

    def del_action(self, intra_extension_id, action_id):
        raise NotImplementedError()  # pragma: no cover

    # Scope functions

    def get_subject_scopes_dict(self, intra_extension_id, subject_category_id):
        raise NotImplementedError()  # pragma: no cover

    def set_subject_scope_dict(self, intra_extension_id, subject_category_id, subject_scope_id, subject_scope_dict):
        raise NotImplementedError()  # pragma: no cover

    def del_subject_scope(self, intra_extension_id, subject_category_id, subject_scope_id):
        raise NotImplementedError()  # pragma: no cover

    def get_object_scopes_dict(self, intra_extension_id, object_category_id):
        raise NotImplementedError()  # pragma: no cover

    def set_object_scope_dict(self, intra_extension_id, object_category_id, object_scope_id, object_scope_dict):
        raise NotImplementedError()  # pragma: no cover

    def del_object_scope(self, intra_extension_id, object_category_id, object_scope_id):
        raise NotImplementedError()  # pragma: no cover

    def get_action_scopes_dict(self, intra_extension_id, action_category_id):
        raise NotImplementedError()  # pragma: no cover

    def set_action_scope_dict(self, intra_extension_id, action_category_id, action_scope_id, action_scope_dict):
        raise NotImplementedError()  # pragma: no cover

    def del_action_scope(self, intra_extension_id, action_category_id, action_scope_id):
        raise NotImplementedError()  # pragma: no cover

    # Assignment functions

    def get_subject_assignment_list(self, intra_extension_id, subject_id, subject_category_id):
        raise NotImplementedError()  # pragma: no cover

    def set_subject_assignment_list(self, intra_extension_id, subject_id, subject_category_id, subject_assignment_list):
        raise NotImplementedError()  # pragma: no cover

    def add_subject_assignment_list(self, intra_extension_id, subject_id, subject_category_id, subject_scope_id):
        raise NotImplementedError()  # pragma: no cover

    def del_subject_assignment(self, intra_extension_id, subject_id, subject_category_id, subject_scope_id):
        raise NotImplementedError()  # pragma: no cover

    def get_object_assignment_list(self, intra_extension_id, object_id, object_category_id):
        raise NotImplementedError()  # pragma: no cover

    def set_object_assignment_list(self, intra_extension_id, object_id, object_category_id, object_assignment_list):
        raise NotImplementedError()  # pragma: no cover

    def add_object_assignment_list(self, intra_extension_id, object_id, object_category_id, object_scope_id):
        raise NotImplementedError()  # pragma: no cover

    def del_object_assignment(self, intra_extension_id, object_id, object_category_id, object_scope_id):
        raise NotImplementedError()  # pragma: no cover

    def get_action_assignment_list(self, intra_extension_id, action_id, action_category_id):
        raise NotImplementedError()  # pragma: no cover

    def set_action_assignment_list(self, intra_extension_id, action_id, action_category_id, action_assignment_list):
        raise NotImplementedError()  # pragma: no cover

    def add_action_assignment_list(self, intra_extension_id, action_id, action_category_id, action_scope_id):
        raise NotImplementedError()  # pragma: no cover

    def del_action_assignment(self, intra_extension_id, action_id, action_category_id, action_scope_id):
        raise NotImplementedError()  # pragma: no cover

    # Meta_rule functions

    def set_aggregation_algorithm_id(self, intra_extension_id, aggregation_algorithm_id):
        raise NotImplementedError()  # pragma: no cover

    def get_aggregation_algorithm_id(self, intra_extension_id):
        raise NotImplementedError()  # pragma: no cover

    def del_aggregation_algorithm(self, intra_extension_id):
        raise NotImplementedError()  # pragma: no cover

    def get_sub_meta_rules_dict(self, intra_extension_id):
        raise NotImplementedError()  # pragma: no cover

    def set_sub_meta_rule_dict(self, intra_extension_id, sub_meta_rule_id, meta_rule_dict):
        raise NotImplementedError()  # pragma: no cover

    def del_sub_meta_rule(self, intra_extension_id, sub_meta_rule_id):
        raise NotImplementedError()  # pragma: no cover

    # Rule functions

    def get_rules_dict(self, intra_extension_id, sub_meta_rule_id):
        raise NotImplementedError()  # pragma: no cover

    def set_rule_dict(self, intra_extension_id, sub_meta_rule_id, rule_id, rule_list):
        raise NotImplementedError()  # pragma: no cover

    def del_rule(self, intra_extension_id, sub_meta_rule_id, rule_id):
        raise NotImplementedError()  # pragma: no cover


class LogDriver(object):

    def authz(self, message):
        """Log authorization message

        :param message: the message to log
        :type message: string
        :return: None
        """
        raise NotImplementedError()  # pragma: no cover

    def debug(self, message):
        """Log debug message

        :param message: the message to log
        :type message: string
        :return: None
        """
        raise NotImplementedError()  # pragma: no cover

    def info(self, message):
        """Log informational message

        :param message: the message to log
        :type message: string
        :return: None
        """
        raise NotImplementedError()  # pragma: no cover

    def warning(self, message):
        """Log warning message

        :param message: the message to log
        :type message: string
        :return: None
        """
        raise NotImplementedError()  # pragma: no cover

    def error(self, message):
        """Log error message

        :param message: the message to log
        :type message: string
        :return: None
        """
        raise NotImplementedError()  # pragma: no cover

    def critical(self, message):
        """Log critical message

        :param message: the message to log
        :type message: string
        :return: None
        """
        raise NotImplementedError()  # pragma: no cover

    def get_logs(self, options):
        """Get logs

        :param options: options to filter log events
        :type options: string eg: "event_number=10,from=2014-01-01-10:10:10,to=2014-01-01-12:10:10,filter=expression"
        :return: a list of log events

        TIME_FORMAT is '%Y-%m-%d-%H:%M:%S'
        """
        raise NotImplementedError()  # pragma: no cover


# class InterExtensionDriver(object):
#
#     # Getter and Setter for InterExtensions
#
#     def get_inter_extensions(self):
#         raise NotImplementedError()  # pragma: no cover
#
#     def get_inter_extension(self, uuid):
#         raise NotImplementedError()  # pragma: no cover
#
#     def create_inter_extensions(self, intra_id, intra_extension):
#         raise NotImplementedError()  # pragma: no cover
#
#     def delete_inter_extensions(self, intra_extension_id):
#         raise NotImplementedError()  # pragma: no cover
#
#
# class VirtualEntityDriver(object):
#
#     # Getter and Setter for InterExtensions
#
#     def get_virtual_entities(self):
#         raise NotImplementedError()  # pragma: no cover
#
#     def create_virtual_entities(self, ve_id, virtual_entity):
#         raise NotImplementedError()  # pragma: no cover
