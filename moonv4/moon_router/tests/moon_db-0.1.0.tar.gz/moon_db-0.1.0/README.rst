DB module for the Moon project
==============================

This package contains the database module for the Moon project
It is designed to provide a driver to access the Moon database.

For any other information, refer to the parent project:

    https://git.opnfv.org/moon
